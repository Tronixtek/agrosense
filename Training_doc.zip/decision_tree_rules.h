/*
 * Auto-generated Decision Tree
 * Training accuracy: 88.4%
 * CV accuracy:       82.4% ± 3.5%
 * Samples:           6400
 * Features:          moisture_pct, texture_code, growth_stage
 * Classes:           0=HOLD, 1=IRRIGATE, 2=URGENT
 *
 * Texture codes: 0=sandy, 1=silty, 2=loamy, 3=clay
 * Growth stages: 0=germination, 1=vegetative, 2=tasseling, 3=grain fill
 */

// ── Irrigation action codes ──────────────────
#define ACTION_HOLD     0
#define ACTION_IRRIGATE 1
#define ACTION_URGENT   2

// ── Texture codes ─────────────────────────────
#define TEXTURE_SANDY 0
#define TEXTURE_SILTY 1
#define TEXTURE_LOAMY 2
#define TEXTURE_CLAY  3

// ── Growth stage codes ────────────────────────
#define STAGE_GERMINATION 0
#define STAGE_VEGETATIVE  1
#define STAGE_TASSELING   2
#define STAGE_GRAIN_FILL  3

int decisionTree(float moisture, int textureCode, int growthStage) {
  if (moisture <= 40.95f) {
    if (moisture <= 17.75f) {
      if (moisture <= 13.65f) {
        if (moisture <= 13.45f) {
          return ACTION_URGENT;  // conf: 0%  n=633
        } else {
          return ACTION_URGENT;  // conf: 5%  n=16
        }
      } else {
        if (growthStage <= 1) {
          if (textureCode <= 3) {
            return ACTION_URGENT;  // conf: 0%  n=63
          } else {
            return ACTION_IRRIGATE;  // conf: 1%  n=51
          }
        } else {
          if (moisture <= 17.25f) {
            return ACTION_URGENT;  // conf: 0%  n=135
          } else {
            return ACTION_URGENT;  // conf: 2%  n=36
          }
        }
      }
    } else {
      if (textureCode <= 1) {
        if (moisture <= 30.45f) {
          if (growthStage <= 1) {
            return ACTION_IRRIGATE;  // conf: 0%  n=70
          } else {
            return ACTION_URGENT;  // conf: 1%  n=98
          }
        } else {
          if (growthStage <= 2) {
            return ACTION_IRRIGATE;  // conf: 0%  n=106
          } else {
            return ACTION_IRRIGATE;  // conf: 1%  n=65
          }
        }
      } else {
        if (moisture <= 22.75f) {
          if (growthStage <= 2) {
            return ACTION_IRRIGATE;  // conf: 0%  n=225
          } else {
            return ACTION_URGENT;  // conf: 0%  n=121
          }
        } else {
          if (growthStage <= 1) {
            return ACTION_IRRIGATE;  // conf: 0%  n=228
          } else {
            return ACTION_IRRIGATE;  // conf: 0%  n=869
          }
        }
      }
    }
  } else {
    if (moisture <= 54.05f) {
      if (textureCode <= 1) {
        if (growthStage <= 1) {
          if (moisture <= 42.80f) {
            return ACTION_IRRIGATE;  // conf: 4%  n=13
          } else {
            return ACTION_HOLD;  // conf: 4%  n=24
          }
        } else {
          if (moisture <= 50.65f) {
            return ACTION_IRRIGATE;  // conf: 1%  n=97
          } else {
            return ACTION_IRRIGATE;  // conf: 1%  n=50
          }
        }
      } else {
        if (growthStage <= 2) {
          return ACTION_HOLD;  // conf: 0%  n=178
        } else {
          if (moisture <= 49.65f) {
            return ACTION_IRRIGATE;  // conf: 0%  n=184
          } else {
            return ACTION_HOLD;  // conf: 1%  n=61
          }
        }
      }
    } else {
      if (moisture <= 65.95f) {
        if (textureCode <= 1) {
          if (growthStage <= 2) {
            return ACTION_HOLD;  // conf: 1%  n=66
          } else {
            return ACTION_IRRIGATE;  // conf: 0%  n=104
          }
        } else {
          if (moisture <= 54.35f) {
            return ACTION_HOLD;  // conf: 8%  n=12
          } else {
            return ACTION_HOLD;  // conf: 0%  n=321
          }
        }
      } else {
        return ACTION_HOLD;  // conf: 0%  n=1294
      }
    }
  }
}

// ── Helper: convert texture name to code ─────
int textureNameToCode(const char* texture) {
  if (strcmp(texture, "sandy") == 0) return TEXTURE_SANDY;
  if (strcmp(texture, "silty") == 0) return TEXTURE_SILTY;
  if (strcmp(texture, "loamy") == 0) return TEXTURE_LOAMY;
  if (strcmp(texture, "clay")  == 0) return TEXTURE_CLAY;
  return TEXTURE_LOAMY;  // default
}

// ── Wrapper: use texture name + stage int ─────
int decide(float moisture, const char* texture, int growthStage = 1) {
  return decisionTree(moisture, textureNameToCode(texture), growthStage);
}

const char* actionName(int action) {
  if (action == ACTION_URGENT)   return "URGENT";
  if (action == ACTION_IRRIGATE) return "IRRIGATE";
  return "HOLD";
}