/*
 * ╔══════════════════════════════════════════════════════════╗
 * ║        AgroSense — Autonomous Maize Irrigation           ║
 * ║        ESP32 Firmware  v3.0                              ║
 * ║        FUTO Computer Science  ·  2025                    ║
 * ╚══════════════════════════════════════════════════════════╝
 *
 * HARDWARE:
 *   3× Capacitive soil moisture sensors  → GPIO 34, 35, 32
 *   4-channel relay module (active LOW)  → GPIO 26, 27, 14  (CH4/GPIO12 spare)
 *
 * LIBRARIES REQUIRED (install via Arduino Library Manager):
 *   - ArduinoJson   by Benoit Blanchon        (v6.x)
 *   - WiFi          built-in ESP32 board package
 *   - HTTPClient    built-in ESP32 board package
 *
 * FIREBASE:
 *   Project  : agrosense-e8582
 *   RTDB URL : https://agrosense-e8582-default-rtdb.firebaseio.com
 *
 * FIREBASE DATA STRUCTURE:
 *   /sensors/zone0..2/
 *       moisture      float   — soil moisture 0–100 %
 *       texture       string  — sandy | loamy | clay | silty
 *       growthStage   int     — 0=germination 1=vegetative 2=tasseling 3=grain fill
 *       pump          bool    — true = pump running
 *       action        string  — HOLD | IRRIGATE | URGENT
 *       threshold     float   — irrigation threshold for current texture
 *       manual        bool    — true = manual override active
 *       name          string  — zone display name
 *   /system/
 *       uptime        int     — seconds since boot
 *       irrCount      int     — total irrigations since boot
 *       mode          string  — auto | manual
 *       ip            string  — ESP32 IP on local network
 *       rssi          int     — WiFi signal strength (dBm)
 *       lastSeen      long    — millis/1000 timestamp
 *   /commands/
 *       mode          string  — dashboard writes "auto"/"manual" here
 *       stopAll       bool    — dashboard writes true to stop all pumps
 *       growthStage   int     — dashboard writes 0-3 to change growth stage
 *       zones/zone0..2/pump   bool  — dashboard writes per-pump state
 *       textures/zone0..2     string — dashboard writes per-zone texture
 *
 * SENSOR CALIBRATION:
 *   Capacitive sensors read HIGHER when DRY, LOWER when WET.
 *   1. Open Serial Monitor (115200 baud)
 *   2. Hold sensor in dry air  → note raw ADC → set DRY_VAL
 *   3. Dip sensor tip in water → note raw ADC → set WET_VAL
 *   4. Re-flash the firmware
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include "decision_tree_rules.h"

// ════════════════════════════════════════════════
//  CONFIGURATION — edit these before flashing
// ════════════════════════════════════════════════
const char* WIFI_SSID     = "VT";
const char* WIFI_PASSWORD = "password";

// Firebase Realtime Database
const char* FB_URL    = "https://agrosense-e8582-default-rtdb.firebaseio.com";
const char* FB_SECRET = "wM9loNSpnjREDCLgXqHOoRR6G0I5izVgPzdESg8i";

// ════════════════════════════════════════════════
//  PIN MAP
// ════════════════════════════════════════════════
const int SENSOR_PINS[3] = {34, 35, 32};  // capacitive sensor AO pins
const int RELAY_PINS[3]  = {26, 27, 14};  // pump 1, 2, 3 (4-ch relay CH1–CH3)
const int RELAY_SPARE    = 12;             // 4-ch relay CH4 — reserved

// ════════════════════════════════════════════════
//  SENSOR CALIBRATION
//  Adjust these values for your specific sensors.
//  Typical range for common blue capacitive modules:
//    Dry air  → ~3200   Wet (submerged) → ~1400
// ════════════════════════════════════════════════
const int DRY_VAL = 3200;
const int WET_VAL = 1400;

// ════════════════════════════════════════════════
//  ZONE CONFIGURATION
// ════════════════════════════════════════════════
struct Zone {
  const char* name;         // display name
  int         sensorPin;    // analog GPIO for sensor AO
  int         relayPin;     // digital GPIO for relay IN
  char        texture[12];  // soil texture string
  int         growthStage;  // 0–3
  float       moisture;     // current reading 0–100 %
  bool        pumpOn;       // relay state
  bool        manualOverride; // true = ignore ML, dashboard controls this pump
};

Zone zones[3] = {
  { "Zone Alpha", 34, 26, "loamy", 1, 0.0f, false, false },
  { "Zone Beta",  35, 27, "sandy", 1, 0.0f, false, false },
  { "Zone Gamma", 32, 14, "clay",  1, 0.0f, false, false },
};

// ════════════════════════════════════════════════
//  TIMING INTERVALS  (milliseconds)
// ════════════════════════════════════════════════
const unsigned long SENSOR_INTERVAL  = 2000;  // read sensors every 2 s
const unsigned long WRITE_INTERVAL   = 5000;  // push to Firebase every 5 s
const unsigned long COMMAND_INTERVAL = 3000;  // poll commands every 3 s
const unsigned long WIFI_RETRY       = 10000; // retry WiFi if dropped

unsigned long lastSensorRead    = 0;
unsigned long lastFirebaseWrite = 0;
unsigned long lastCommandPoll   = 0;
unsigned long lastWifiCheck     = 0;
unsigned long bootTime          = 0;

// ════════════════════════════════════════════════
//  SYSTEM STATE
// ════════════════════════════════════════════════
int  irrigationsToday = 0;
bool systemMode_auto  = true;   // true = ML controls pumps, false = manual

// ════════════════════════════════════════════════
//  SENSOR READING
//  Average 10 samples to reduce ADC noise.
//  Capacitive: higher ADC = drier soil.
// ════════════════════════════════════════════════
float readMoisture(int pin) {
  long sum = 0;
  for (int i = 0; i < 10; i++) {
    sum += analogRead(pin);
    delay(5);
  }
  int raw = (int)(sum / 10);

  // Print raw for calibration help
  Serial.printf("    raw ADC pin %d = %d\n", pin, raw);

  // Map: DRY_VAL → 0%, WET_VAL → 100%
  float pct = (float)(DRY_VAL - raw) / (float)(DRY_VAL - WET_VAL) * 100.0f;
  return constrain(pct, 0.0f, 100.0f);
}

// ════════════════════════════════════════════════
//  RELAY CONTROL  (active LOW)
//  LOW  → relay coil energised → COM–NO closes → pump ON
//  HIGH → relay coil off       → COM–NO open   → pump OFF
// ════════════════════════════════════════════════
void setPump(int zoneIndex, bool on) {
  digitalWrite(zones[zoneIndex].relayPin, on ? LOW : HIGH);
  zones[zoneIndex].pumpOn = on;
}

void stopAllPumps() {
  for (int i = 0; i < 3; i++) {
    setPump(i, false);
    zones[i].manualOverride = false;
  }
  Serial.println(F("[PUMP] All pumps stopped"));
}

// ════════════════════════════════════════════════
//  WIFI — connect / reconnect
// ════════════════════════════════════════════════
bool connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return true;

  Serial.printf("[WiFi] Connecting to \"%s\"", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  int tries = 0;
  while (WiFi.status() != WL_CONNECTED && tries++ < 40) {
    delay(500);
    Serial.print(".");
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("\n[WiFi] Connected!  IP: %s  RSSI: %d dBm\n",
                  WiFi.localIP().toString().c_str(), WiFi.RSSI());
    return true;
  }

  Serial.println(F("\n[WiFi] Failed — will retry"));
  return false;
}

// ════════════════════════════════════════════════
//  FIREBASE HELPERS
// ════════════════════════════════════════════════
String fbUrl(const String& path) {
  return String(FB_URL) + path + ".json?auth=" + FB_SECRET;
}

// HTTP PUT — write JSON to a Firebase path
bool fbPut(const String& path, const String& body) {
  if (WiFi.status() != WL_CONNECTED) return false;
  HTTPClient http;
  http.begin(fbUrl(path));
  http.addHeader("Content-Type", "application/json");
  int code = http.sendRequest("PUT", body);
  http.end();
  if (code != 200) Serial.printf("[FB] PUT %s → HTTP %d\n", path.c_str(), code);
  return (code == 200);
}

// HTTP GET — read JSON from a Firebase path
String fbGet(const String& path) {
  if (WiFi.status() != WL_CONNECTED) return "null";
  HTTPClient http;
  http.begin(fbUrl(path));
  int code = http.GET();
  String payload = "null";
  if (code == 200) {
    payload = http.getString();
  } else {
    Serial.printf("[FB] GET %s → HTTP %d\n", path.c_str(), code);
  }
  http.end();
  return payload;
}

// ════════════════════════════════════════════════
//  WRITE STATE TO FIREBASE
//  Pushes all sensor readings and system info in one PUT.
// ════════════════════════════════════════════════
void writeToFirebase() {
  // Use a larger document for safety
  StaticJsonDocument<1536> doc;

  // /sensors — zone readings
  JsonObject sensors = doc.createNestedObject("sensors");
  for (int i = 0; i < 3; i++) {
    String key = "zone" + String(i);
    JsonObject z = sensors.createNestedObject(key);
    z["name"]        = zones[i].name;
    z["moisture"]    = (float)round(zones[i].moisture * 10.0f) / 10.0f;
    z["texture"]     = zones[i].texture;
    z["growthStage"] = zones[i].growthStage;
    z["pump"]        = zones[i].pumpOn;
    z["action"]      = actionName(
                         decide(zones[i].moisture,
                                zones[i].texture,
                                zones[i].growthStage));
    z["threshold"]   = getThreshold(zones[i].texture);
    z["manual"]      = zones[i].manualOverride;
  }

  // /system — device status
  JsonObject sys = doc.createNestedObject("system");
  sys["uptime"]   = (long)((millis() - bootTime) / 1000UL);
  sys["irrCount"] = irrigationsToday;
  sys["mode"]     = systemMode_auto ? "auto" : "manual";
  sys["ip"]       = WiFi.localIP().toString();
  sys["rssi"]     = WiFi.RSSI();
  sys["lastSeen"] = (long)(millis() / 1000UL);

  String body;
  serializeJson(doc, body);

  if (fbPut("/", body)) {
    Serial.println(F("[FB] State written OK"));
  }
}

// ════════════════════════════════════════════════
//  POLL COMMANDS FROM FIREBASE
//  Dashboard writes to /commands, ESP32 reads and acts.
// ════════════════════════════════════════════════
void pollCommands() {
  String raw = fbGet("/commands");
  if (raw == "null" || raw.length() < 3) return;

  StaticJsonDocument<512> doc;
  DeserializationError err = deserializeJson(doc, raw);
  if (err) {
    Serial.printf("[CMD] JSON parse error: %s\n", err.c_str());
    return;
  }

  // ── Mode change ───────────────────────────
  if (doc.containsKey("mode")) {
    const char* m  = doc["mode"];
    bool newAuto   = (strcmp(m, "auto") == 0);
    if (newAuto != systemMode_auto) {
      systemMode_auto = newAuto;
      // When switching to auto, stop all manual pumps for safety
      if (systemMode_auto) stopAllPumps();
      for (int i = 0; i < 3; i++)
        zones[i].manualOverride = !systemMode_auto;
      Serial.printf("[CMD] Mode → %s\n", systemMode_auto ? "AUTO" : "MANUAL");
    }
  }

  // ── Emergency stop ────────────────────────
  if (doc["stopAll"] == true) {
    stopAllPumps();
    systemMode_auto = true;
    // Acknowledge by clearing the flag
    fbPut("/commands/stopAll", "false");
    Serial.println(F("[CMD] EMERGENCY STOP executed"));
  }

  // ── Per-zone pump commands ────────────────
  if (doc.containsKey("zones")) {
    for (int i = 0; i < 3; i++) {
      String key = "zone" + String(i);
      if (doc["zones"].containsKey(key)) {
        bool on = (bool)doc["zones"][key]["pump"];
        if (zones[i].pumpOn != on) {
          zones[i].manualOverride = true;
          setPump(i, on);
          Serial.printf("[CMD] Zone %d pump → %s (manual)\n",
                        i + 1, on ? "ON" : "OFF");
        }
      }
    }
  }

  // ── Soil texture update ───────────────────
  if (doc.containsKey("textures")) {
    for (int i = 0; i < 3; i++) {
      String key = "zone" + String(i);
      if (doc["textures"].containsKey(key)) {
        const char* tex = doc["textures"][key];
        strncpy(zones[i].texture, tex, sizeof(zones[i].texture) - 1);
        zones[i].texture[sizeof(zones[i].texture) - 1] = '\0';
        Serial.printf("[CMD] Zone %d texture → %s\n", i + 1, zones[i].texture);
      }
    }
  }

  // ── Growth stage update ───────────────────
  if (doc.containsKey("growthStage")) {
    int stage = (int)doc["growthStage"];
    stage = constrain(stage, 0, 3);
    for (int i = 0; i < 3; i++) zones[i].growthStage = stage;
    const char* stageNames[] = {
      "Germination","Vegetative","Tasseling","Grain fill"
    };
    Serial.printf("[CMD] Growth stage → %s\n", stageNames[stage]);
  }
}

// ════════════════════════════════════════════════
//  SETUP
// ════════════════════════════════════════════════
void setup() {
  Serial.begin(115200);
  delay(500);

  Serial.println(F("\n╔══════════════════════════════╗"));
  Serial.println(F("║  AgroSense v3.0 — Booting    ║"));
  Serial.println(F("╚══════════════════════════════╝"));

  // ── Relay pins: set HIGH BEFORE pinMode
  //    This prevents a glitch that briefly closes the relay on boot
  digitalWrite(RELAY_SPARE, HIGH);
  for (int i = 0; i < 3; i++) {
    digitalWrite(RELAY_PINS[i], HIGH);
    pinMode(RELAY_PINS[i], OUTPUT);
  }
  pinMode(RELAY_SPARE, OUTPUT);
  Serial.println(F("[RELAY] All channels initialised OFF"));

  // ── ADC: 12-bit resolution (0–4095)
  analogReadResolution(12);
  Serial.println(F("[ADC]   12-bit resolution set"));

  // ── Connect to WiFi
  connectWiFi();

  // ── Initial sensor read + calibration output
  Serial.println(F("[SENSOR] Initial readings:"));
  for (int i = 0; i < 3; i++) {
    zones[i].moisture = readMoisture(zones[i].sensorPin);
    Serial.printf("  Zone %d (%s): %.1f%%\n",
                  i + 1, zones[i].name, zones[i].moisture);
  }

  bootTime = millis();

  // ── Push initial state to Firebase
  writeToFirebase();

  // ── Clear any stale commands left in Firebase
  fbPut("/commands/stopAll",   "false");
  fbPut("/commands/mode",      "\"auto\"");

  Serial.println(F("\n[BOOT] Setup complete"));
  Serial.printf(  "[BOOT] Dashboard → https://agrosense-e8582.web.app\n");
  Serial.println(F("╔══════════════════════════════╗"));
  Serial.println(F("║  Entering main loop...        ║"));
  Serial.println(F("╚══════════════════════════════╝\n"));
}

// ════════════════════════════════════════════════
//  LOOP
// ════════════════════════════════════════════════
void loop() {
  unsigned long now = millis();

  // ── WiFi watchdog: reconnect if dropped ───
  if (now - lastWifiCheck >= WIFI_RETRY) {
    lastWifiCheck = now;
    if (WiFi.status() != WL_CONNECTED) {
      Serial.println(F("[WiFi] Connection lost — reconnecting..."));
      connectWiFi();
    }
  }

  // ── Read sensors + run Decision Tree ──────
  if (now - lastSensorRead >= SENSOR_INTERVAL) {
    lastSensorRead = now;

    Serial.println(F("[SENSOR] Reading all zones..."));
    for (int i = 0; i < 3; i++) {
      zones[i].moisture = readMoisture(zones[i].sensorPin);

      // Run ML only in auto mode and when not manually overridden
      if (systemMode_auto && !zones[i].manualOverride) {
        int  action = decide(zones[i].moisture,
                             zones[i].texture,
                             zones[i].growthStage);
        bool should = (action >= ACTION_IRRIGATE);

        if (should && !zones[i].pumpOn) {
          setPump(i, true);
          irrigationsToday++;
          Serial.printf("[AUTO] Zone %d → %-8s  moisture=%.1f%%  Pump ON\n",
                        i + 1, actionName(action), zones[i].moisture);
        }
        if (!should && zones[i].pumpOn) {
          setPump(i, false);
          Serial.printf("[AUTO] Zone %d → HOLD       moisture=%.1f%%  Pump OFF\n",
                        i + 1, zones[i].moisture);
        }
        if (action == ACTION_HOLD) {
          Serial.printf("[AUTO] Zone %d → HOLD       moisture=%.1f%%\n",
                        i + 1, zones[i].moisture);
        }
      } else if (zones[i].manualOverride) {
        Serial.printf("[MANU] Zone %d  moisture=%.1f%%  (manual override)\n",
                      i + 1, zones[i].moisture);
      }
    }
  }

  // ── Write state to Firebase ───────────────
  if (now - lastFirebaseWrite >= WRITE_INTERVAL) {
    lastFirebaseWrite = now;
    writeToFirebase();
  }

  // ── Poll commands from Firebase ───────────
  if (now - lastCommandPoll >= COMMAND_INTERVAL) {
    lastCommandPoll = now;
    pollCommands();
  }
}
